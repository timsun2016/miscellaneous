<?php

// NOTE: This is used to install/upgrade the latest version fs-proxy database
if ( php_sapi_name() != 'cli' ) die( 'Must be run via cli, exiting.' );

require __DIR__ . '/../vendor/catfan/medoo/medoo.php';
require __DIR__ . '/common.php';

loadProxyDatabase();

// Set connection variable
$connection = $GLOBALS[ 'databases' ][ 'proxy_connection' ];

// Create table 'mappings'
$connection->exec("CREATE TABLE `mappings` (
                        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                        `comment` VARCHAR(200) NOT NULL,
                        `path` VARCHAR(200) NOT NULL,
                        `url` VARCHAR(500) NOT NULL,
                        `httpdwngrd` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
                        `kepalv` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
                        INDEX `Id` (`id`)
                    )
");

// Add 'pooled' to table 'mappings'
$connection->exec("ALTER TABLE mappings ADD pooled TINYINT(1) NOT NULL DEFAULT '0';");

// Add 'testurl' to table 'mappings'
$connection->exec("ALTER TABLE mappings ADD testurl VARCHAR(200) NOT NULL;");
