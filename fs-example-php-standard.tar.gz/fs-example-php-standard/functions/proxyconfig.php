<?php

class virtual_host
{
	public $cT;
	public $cCRLF;
	public $cCRLFT;
	public $header;
	public $locations;
	
	function __construct()
	{
		$this->cT 		= "\t";
		$this->cCRLF 	= "\r\n";
		$this->cCRLFT 	= $this->cCRLF . $this->cT;
		$this->head 	= $this->cCRLFT . "DocumentRoot /var/www/html/proxy" . $this->cCRLFT .
			"SSLProxyEngine On" . $this->cCRLFT .
			"SSLProxyCheckPeerName off" . $this->cCRLFT .
			"SSLProxyVerify none" . $this->cCRLFT .
			"SSLProxyCheckPeerCN off" . $this->cCRLFT .
			"SSLProxyCheckPeerExpire off";
	}
	
	public function addLocation( $location )
	{
		$this->locations[] = $location;
    }
	
	public function generateOutput( $type )
	{
		$output 	= $this->generateXML();
		$fileName 	= 'config.conf';
		
		switch( $type )
		{
			case 'file':
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="' . $fileName . '"');
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . strlen( $output ));
				echo( $output );
				break;
			default:
				echo( '<pre>' . htmlentities( $output ) . '</pre>' );
				break; 
		}
	}
	
	public function generateXML()
	{			
		$result = "<VirtualHost *:80>" . $this->head . $this->cCRLF;
		
		foreach( $this->locations as $item )
		{
			if( isset( $item->comment ) && !empty( $item->comment ) ) $result .= $this->cCRLFT . '#' . $item->comment;
			$result .= $this->cCRLFT . '<Location /' . stripslashes( $item->head ) . '>';
			$result .= $this->cCRLFT . $this->cT . 'ProxyPass ' . $item->proxypass . ' retry=0 disablereuse=On keepalive=Off';
			if( $item->forceproxy == 1 ) $result .= $this->cCRLFT . $this->cT . 'SetEnv force-proxy-request-1.0 1';
			//if( $item->keepalive == 1 ) $result .= $this->cCRLFT . $this->cT . 'SetEnv proxy-nokeepalive 1';
			if( $item->downgrade == 1 ) $result .= $this->cCRLFT . $this->cT . 'SetEnv downgrade-1.0 1';
			//if( $item->pooled == 1 ) $result .= $this->cCRLFT . $this->cT . 'SetEnv proxy-initial-not-pooled 1';
			$result .= $this->cCRLFT . $this->cT . 'SetEnv proxy-initial-not-pooled 1';
			$result .= $this->cCRLFT . '</Location>' . $this->cCRLF;
		}
		
		$result .= "</VirtualHost>";
		
		return $result;
	}
}

class location
{
	public $head;
	public $proxypass;
	public $comment;
	public $forceproxy;
	public $keepalive;
	public $downgrade;
	public $pooled;
	
	function __construct( $head, $proxypass, $comment, $forceproxy, $keepalive, $downgrade, $pooled )
	{
        $this->head 		= $head;
        $this->proxypass 	= $proxypass;
        $this->comment 		= $comment;
		$this->forceproxy 	= $forceproxy;
        $this->keepalive 	= $keepalive;
        $this->downgrade 	= $downgrade;
		$this->pooled 		= $pooled;
    }
}

function generateRealVirtualHost()
{
	/*
	$whitelist = [
        '127.0.0.1',
        '::1'
    ];

    if( !in_array( $_SERVER[ 'REMOTE_ADDR' ], $whitelist )) die( 'Error: This script can only be run by localhost, exiting.' );
	*/
	
	$virtualHost = new virtual_host();
	
	$count = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->count( 'mappings' );
	
	if( $count > 0 )
	{
		$result = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->select( 'mappings', '*' );
				
		foreach( $result as $item )
		{
			$location = new location(
				parsePath( $item[ 'path' ] ),
				parseURL( $item[ 'url' ] ),
				parseComment( $item[ 'comment' ] ),
				(int)$item[ 'httpdwngrd' ], // Business logic: force-proxy-request-1.0 && downgrade-1.0 run in tandem
				(int)$item[ 'kepalv' ],
				(int)$item[ 'httpdwngrd' ],
				(int)$item[ 'pooled' ]
			);
			
			$virtualHost->addLocation( $location );
		}
	}
	
	return $virtualHost;
}

function generateFakeVirtualHost()
{
	$virtualHost = new virtual_host();
	
	$names = [
		'apple', 'banana', 'carrot',
		'crispy', 'berry', 'maple',
		'golden', 'nectarine', 'pear',
		'mellon', 'plum', 'orange'
	];
	
	// Generate dummy locations
	for( $i = 0; $i <= 25; $i++ )
	{
		$locationRand = $names[ rand( 0, count( $names ) - 1 ) ] . $i;
		
		$location = new location(
			$locationRand,
			'https://www.' . $locationRand . '.com',
			'test comment',
			rand( 0, 1 ),
			rand( 0, 1 ),
			rand( 0, 1 ),
			rand( 0, 1 )
		);
		
		$virtualHost->addLocation( $location );
	}
	
	return $virtualHost;
}
