<?php

define( 'SMTPServer', 'example.firmstep.com' );
define( 'SMTPPort', 25 );
define( 'FromEmail', 'example@firmstep.com' );
define( 'ToEmail', 'example@firmstep.com' );
define( 'CCEmail', 'example@firmstep.com' );

?>
