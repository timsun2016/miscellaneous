<?php

// NOTE: Must keep class names PascalCase format otherwise object deserialization in fs-platform-admin will not work
class Mapping
{
    public $path;
    public $url;
    public $comment;
    public $httpdwngrd;
    public $kepalv;
    public $pooled;
    public $testurl;

    function __construct( $path, $url, $comment, $httpdwngrd, $kepalv, $pooled, $testurl )
    {
        $this->path         = $path;
        $this->url          = $url;
        $this->comment      = $comment;
        $this->httpdwngrd   = $httpdwngrd;
        $this->kepalv       = $kepalv;
        $this->pooled       = $pooled;
        $this->testurl      = $testurl;
    }
}

// NOTE, Must keep class names PascalCase format otherwise JSON conversion in fs-platform-admin will not work
class MappingList
{
    public $count;
    public $details;

    function addMapping( $mapping )
    {
        $this->details[] = (array)$mapping;
    }
}

// NOTE, Must keep class names PascalCase format otherwise JSON conversion in fs-platform-admin will not work
class Parameters
{
    public $parameters = [];

    public function setParameter( $name, $value )
    {
        $this->parameters = array_merge( $this->parameters, [ $name => $value ] );
    }

    public function getParameters()
    {
        return $this->parameters;
    }
}

// NOTE, Must keep class names PascalCase format otherwise JSON conversion in fs-platform-admin will not work
class ProxyMappings
{
    function __construct( $type ) 
    {
        setRequestResponseType( $type );
    }

    public function get( $object )
    {
        // Find data for path
        $result = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->select( 'mappings', '*', [ 'path' => $object->path ] );

        foreach( $result as $item )
        {
            parseObjectToOutput( new Mapping(
                    parsePath( $item[ 'path' ] ),
                    parseURL( $item[ 'url' ] ),
                    parseComment( $item[ 'comment' ], false ),
                    (bool)$item[ 'httpdwngrd' ],
                    (bool)$item[ 'kepalv' ],
                    (bool)$item[ 'pooled' ],
                    parseTestURL( $item[ 'testurl' ] )
                )
            );
        }

        parseErrorToOutput( 'No mappings found for path: ' . $object->path );
    }

    public function post( $object )
    {
        $mappingList    = new MappingList();
        $where          = new Parameters();

        if( !empty( $object->path ) ) $where->setParameter( 'path[~]', $object->path );
        
        $count = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->count( 'mappings', $where->getParameters() );
        $mappingList->count = $count;

        if( $count > 0 )
        {
            if( $object->limit !== null && $object->offset !== null )
            {
                $where->setParameter( 'LIMIT', [ $object->offset, $object->limit ] );
            }
            else if( $object->limit != null )
            {
                $where->setParameter( 'LIMIT', $object->limit );
            }
            else if( $object->offset != null )
            {
                $where->setParameter( 'LIMIT', [ $object->offset, 99999999 ] );
            }

            $result = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->select( 'mappings', '*', $where->getParameters() );

            foreach( $result as $item )
            {
                $mappingList->addMapping( new Mapping(
                        parsePath( $item[ 'path' ] ),
                        parseURL( $item[ 'url' ] ),
                        parseComment( $item[ 'comment' ], false ),
                        (bool)$item[ 'httpdwngrd' ],
                        (bool)$item[ 'kepalv' ],
                        (bool)$item[ 'pooled' ],
                        parseTestURL( $item[ 'testurl' ] )
                    )
                );
            }
        }

        parseObjectToOutput( $mappingList );
    }

    public function create( $object )
    {
        // Check if path exists, if it doesn't create a new path and return true
        $count = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->count( 'mappings', [ 'path' => $object->path ] );

        if( $count === 0 )
        {
            $GLOBALS[ 'databases' ][ 'proxy_connection' ]->insert( 'mappings', [
                    'path'          => $object->path,
                    'url'           => $object->url,
                    'comment'       => $object->comment,
                    'httpdwngrd'    => $object->httpdwngrd,
                    'kepalv'        => $object->kepalv,
                    'pooled'        => $object->pooled,
                    'testurl'       => $object->testurl
                ]
            );

            return parseObjectToOutput( true );
        }

       parseErrorToOutput( 'Mapping already exists for path: ' . $object->path );
    }

    public function update( $object )
    {
        // Check if path exists, if it doesn't return false
        $count = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->count( 'mappings', [ 'path' => $object->path ]);

        if( $count == 1 )
        {
            $GLOBALS[ 'databases' ][ 'proxy_connection' ]->update( 'mappings', [
                    'url'           => $object->url,
                    'comment'       => $object->comment,
                    'httpdwngrd'    => $object->httpdwngrd,
                    'kepalv'        => $object->kepalv,
                    'pooled'        => $object->pooled,
                    'testurl'       => $object->testurl
                ], [
                    'path'          => $object->path
                ]
            );

            parseObjectToOutput( true );
        }

        parseErrorToOutput( 'No mapping found for path: ' . $object->path . ' cannot update' );
    }

    public function delete( $object )
    {
        // Check if path exists before attempting delete
        $count = $GLOBALS[ 'databases' ][ 'proxy_connection' ]->count( 'mappings', [ 'path' => $object->path ] );

        if( $count > 0 )
        {
            $GLOBALS[ 'databases' ][ 'proxy_connection' ]->delete( 'mappings', [ 'path' => $object->path ] );
            parseObjectToOutput( true );
        }

        parseErrorToOutput( 'No mapping found for path: ' . $object->path . ' cannot delete' );
    }

    public function validateRequired( $required, $mode = '')
    {
        foreach( $required as $item )
        {
            switch( $mode )
            {
                case 'strict':
                    if( !isset( $_POST[ $item ] ) ) parseErrorToOutput( 'Required: ' . $item . ' is missing from POST object' );
                    if( $_POST[ $item ] === null || $_POST[ $item ] === '' ) parseErrorToOutput( 'Required: ' . $item . ' cannot be empty' );
                    break;
                case 'default':
                    if( $_POST[ $item ] === null || $_POST[ $item ] === '' ) $_POST[ $item ] = 0;
                    break;
                default:
                    if( !isset( $_POST[ $item ] ) ) parseErrorToOutput( 'Required: ' . $item . ' is missing from POST object' );
                    break;
            }
        }
    }
}
