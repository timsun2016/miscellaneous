<?php
$GLOBALS[ 'databases' ]     = [];
$GLOBALS[ 'requesttype' ]   = '';
$GLOBALS[ 'responsetype' ]  = '';

function loadProxyDatabase()
{
    // Initialise connection
    $connection = json_decode( file_get_contents( __DIR__ . '/database.conf' ) );

    // Validate connection
    if( is_null( $connection ) ) die( 'Error: Invalid json in database.conf, exiting.' );
    
    $connection = (array)$connection;

    $search = [
        'type',
        'host',
        'name',
        'username',
        'password'
    ];

    foreach( $search as $required ) 
    {
        if( !isset( $connection[ $required ] ) && !empty( $connection[ $required ] ) )
        {
            die( 'Error: Value "' . $required . '" is required in database configuration, exiting.' );
        }
    }

    $connection[ "alias" ] = 'proxy_connection';

    loadDatabase( $connection );
}

function loadDatabase( $connection )
{
    if( !isset( $GLOBALS[ 'databases' ][ $connection[ 'alias' ] ] ))
    {
        $GLOBALS[ 'databases' ][ $connection[ 'alias' ] ] = new medoo([
            'database_type' => $connection[ 'type' ],
            'server'        => $connection[ 'host' ],
            'database_name' => $connection[ 'name' ],
            'username'      => $connection[ 'username' ],
            'password'      => $connection[ 'password' ],
            'charset'       => 'utf8'
        ]);
    }
}

function setRequestResponseType( $type )
{
    // Validate input
    if( !in_array( $type, [ 'json', 'xml', 'output' ] ) ) die( "Error: Only JSON, XML and Output types are accepted" );
    if( is_null( $type ) ) die( "Error: Output type missing from querystring" );
    if( empty( $type ) ) die( "Error: Output type in querystring is empty" );

    $GLOBALS[ 'requesttype' ]   = $type;
    $GLOBALS[ 'responsetype' ]  = isset( $_POST[ 'responsetype' ] ) ? $_POST[ 'responsetype' ] : $type;
}

function parseGenericToObject( $data )
{
    $testJSON = json_decode( $data );

    // JSON is valid
    if( json_last_error() === JSON_ERROR_NONE )
    {
        setRequestResponseType( 'json' );
        return $testJSON;
    }

    $testXML = simplexml_load_string( $data );

    // XML is valid
    if( $testxml )
    {
        setRequestResponseType( 'xml' );
        return $testXML;
    }

    return false;
}

function parseObjectToOutput( $object )
{
    switch( $GLOBALS[ 'responsetype' ] )
    {
        case 'json':
            die( json_encode( $object ) );
        case 'xml':
            die( generateValidXmlFromObj( (object)(array)$object ) );
        case 'output':
            die( var_dump( $object ) );
    }
}

function parseErrorToOutput( $error )
{
    $object                 = new stdClass();
    $object->error          = $error;
    $object->requesttype    = $GLOBALS[ 'requesttype' ];
    $object->responsetype   = $GLOBALS[ 'responsetype' ];
   
    parseObjectToOutput( $object );
}

function parsePath( $path )
{
    $result = preg_replace( '/[^a-zA-Z0-9-_.]/', '', $path );

    if( $path != $result ) parseErrorToOutput( 'Path must only contain characters a-z, A-Z, 0-9, period, underscore and hyphen' );

    return $result;
}

function parseURL( $url )
{
    // Generic validation
    $result = filter_var( $url, FILTER_SANITIZE_URL );

    if( $url != $result ) parseErrorToOutput( 'URL must not contain any illegal URL characters' );

    // Hash and brackets (For VirtualHost output)
    $result = preg_replace( '/[#<>]/', '', $result );

    if( $url != $result ) parseErrorToOutput( 'URL must not contain hash or bracket characters' );

    return $result;
}

function parseBool( $bool, $name )
{
    switch( $bool )
    {
        case "0":
            return false;
        case '1':
            return true;
        default:
            parseErrorToOutput( $name . ' is not boolean' );
    }
}

function parseNumeric( $numeric, $name )
{
    if( !is_numeric( $numeric ) ) parseErrorToOutput( $name . ' is not numeric' );

    return $numeric;
}

function parseTestURL( $url )
{
    $result = filter_var( $url, FILTER_SANITIZE_URL );

    if( $url != $result ) parseErrorToOutput( 'TestURL must not contain any illegal URL characters' );

    $result = preg_replace( '/[^a-zA-Z0-9-_.]/', '', $result );

    if( $url != $result ) parseErrorToOutput( 'TestURL must only contain characters a-z, A-Z, 0-9, period, underscore and hyphen' );

    return $result;
}

function parseComment( $comment, $strict = true )
{
    // General & Special new line characters
    $result = str_replace( [ '\n', '\r' ], '. ' , preg_replace( '~\R~u', '', $comment ) );

    if( $strict && $comment != $result ) parseErrorToOutput( 'Comment must not contain linefeed characters' );
    
    // Hash and brackets
    $result = preg_replace( '/[#<>]/', '', $result );

    if( $strict && $comment != $result ) parseErrorToOutput( 'Comment must not contain hash or bracket characters' );

    return $result;
}

function generateRequestObject()
{
    $request                = new stdClass();
    $request->path          = isset( $_POST[ 'path' ] )         ? parsePath( $_POST[ 'path' ] )                                             : null;
    $request->url           = isset( $_POST[ 'url' ] )          ? parseURL( $_POST[ 'url' ] )                                               : null;
    $request->comment       = isset( $_POST[ 'comment' ] )      ? parseComment( $_POST[ 'comment' ] )                                       : null;
    $request->httpdwngrd    = isset( $_POST[ 'httpdwngrd' ] )   ? parseBool( $_POST[ 'httpdwngrd' ], 'httpdwngrd')                          : null;
    $request->kepalv        = isset( $_POST[ 'kepalv' ] )       ? parseBool( $_POST[ 'kepalv' ], 'kepalv' )                                 : null;
    $request->pooled        = isset( $_POST[ 'pooled' ] )       ? parseBool( $_POST[ 'pooled' ], 'pooled' )                                 : null;
    $request->testurl       = isset( $_POST[ 'testurl' ] )      ? parseTestURL( $_POST[ 'testurl' ] )                                       : null;
    $request->limit         = isset( $_POST[ 'limit' ] )        ? ( $_POST[ 'limit' ] !== 0  ? parseNumeric( $_POST[ 'limit' ], 'Limit' )   : null )    : null;
    $request->offset        = isset( $_POST[ 'offset' ] )       ? ( $_POST[ 'offset' ] !== 0 ? parseNumeric( $_POST[ 'offset' ], 'Offset' ) : null )    : null;

    return $request;
}

function generateValidXmlFromObj( stdClass $obj, $nodeBlock = 'nodes', $nodeName = 'node' )
{
    $arr = get_object_vars( $obj );
    return generateValidXmlFromArray( $arr, $nodeBlock, $nodeName );
}

function generateValidXmlFromArray( $array, $nodeBlock = 'nodes', $nodeName = 'node' )
{
    $xml = '<?xml version="1.0" encoding="UTF-8" ?>';
    $xml .= '<xml><' . $nodeBlock . '>' . generateXmlFromArray( $array, $nodeName ) . '</' . $nodeBlock . '></xml>';
    return $xml;
}

function generateXmlFromArray( $array, $nodeName )
{
    $xml = '';

    if( is_array( $array ) || is_object( $array ) )
    {
        foreach( $array as $key => $value )
        {
            if( is_numeric( $key ) )
            {
                $key = $nodeName;
            }

            $xml .= '<' . $key . '>' . generateXmlFromArray( $value, $nodeName ) . '</' . $key . '>';
        }
    }
    else
    {
        $xml = htmlspecialchars( $array, ENT_QUOTES );
    }

    return $xml;
}
