<?php

require __DIR__ . '/../functions/common.php';
require __DIR__ . '/../functions/proxyconfig.php';
require __DIR__ . '/../functions/proxymapping.php';
$app = require __DIR__ . '/../bootstrap/app.php';
loadProxyDatabase();

// Get Mapping VirtualHost Configuration
$app->get('api/proxy/config/{type}', function( $type ) {
	//generateFakeVirtualHost()->generateOutput( $type );
    generateRealVirtualHost()->generateOutput( $type );
});

// Get Mapping(s) 
$app->post('api/proxy/mapping/{type}', function( $type ) {
    $proxyMapping = new ProxyMappings( $type );
    $request = generateRequestObject();
    
    // MODE #1 - Run single get
    if( !empty( $request->path ) && is_null( $request->limit ) && is_null( $request->offset ) ) $proxyMapping->get( $request );

    // MODE #2 - Run multiple get
    $proxyMapping->post( $request );
});

// Create Mapping
$app->post('api/proxy/mapping/create/{type}', function( $type ) {
    $proxyMapping = new ProxyMappings( $type );
    $proxyMapping->validateRequired( [ 'path', 'url', 'httpdwngrd' ], 'strict' );
    $proxyMapping->validateRequired( [ 'kepalv', 'pooled' ], 'default' );
    $proxyMapping->create( generateRequestObject() );
});

// Update Mapping
$app->post('api/proxy/mapping/update/{type}', function( $type ) {
    $proxyMapping = new ProxyMappings( $type );
    $proxyMapping->validateRequired( [ 'path', 'url', 'httpdwngrd' ], 'strict' );
    $proxyMapping->validateRequired( [ 'kepalv', 'pooled' ], 'default' );
    $proxyMapping->update( generateRequestObject() );
});

// Delete Mapping
$app->post('api/proxy/mapping/delete/{type}', function( $type ) {
    $proxyMapping = new ProxyMappings( $type );
    $proxyMapping->validateRequired( [ 'path' ], 'strict' );
    $proxyMapping->delete( generateRequestObject() );
});

// TEST FUNCTIONS ONLY, DO NOT ENABLE THESE IN LIVE ENVIRONMENT
/*
$app->get('api/proxy/mapping/explode/{type}', function( $type ) { 
        $proxyMapping = new ProxyMappings( $type );
     
        for( $i = 0; $i <= 100; $i++ )
        { 
            // Create $i new records 
            $_POST[ 'path' ]        = 'TESTEXPLODE' . $i; 
            $_POST[ 'url' ]         = 'https://TESTEXPLODE' . $i . '.com'; 
            $_POST[ 'comment' ]     = 'TEST EXPLODE' . $i; 
            $_POST[ 'httpdwngrd' ]  = rand(0,1) == 1; 
            $_POST[ 'kepalv' ]      = rand(0,1) == 1; 
            $_POST[ 'pooled' ]      = rand(0,1) == 1; 
            $_POST[ 'testurl' ]     = "";

            $proxyMapping->create( generateRequestObject() ); 
        }
    }
);
 
$app->get('api/proxy/mapping/compress/{type}', function( $type ) { 
        $proxyMapping = new ProxyMappings( $type );
     
        for( $i = 0; $i <= 100; $i++ )
        { 
            $_POST[ 'path' ] = 'TESTEXPLODE' . $i;
            $proxyMapping->delete(  generateRequestObject() ); 
        } 
     
        return parseObjectToOutput( true ); 
    }
);
*/

$app->run();
